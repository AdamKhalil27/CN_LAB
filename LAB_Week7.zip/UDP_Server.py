import socket
import threading

#First, we want to implement a UDP application supporting multiple users
# We need to create a dictionary to store client addresses

def udp_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(("0.0.0.0", 8889))
    print("UDP Server is listening...")
    while True:
        data, addr = server_socket.recvfrom(1024)
        print("Received from {}: {}".format(addr, data.decode()))

def udp_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    while True:
        message = input("Enter a message: ")
        client_socket.sendto(message.encode(), ("127.0.0.1", 8889))

def main():
    server_thread = threading.Thread(target=udp_server)
    server_thread.start()

    client_thread = threading.Thread(target=udp_client)
    client_thread.start()

if __name__ == "__main__":
    main()
