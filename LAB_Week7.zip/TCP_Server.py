import socket
import threading

#Then, we want to implement a TCP application supporting multiple users

def tcp_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("0.0.0.0", 8888))
    server_socket.listen(5)
    print("TCP Server is listening...")
    client_socket, client_address = server_socket.accept()

    while True:
        data = client_socket.recv(1024)
        print("Received from {}:{}".format(client_address[0], client_address[1], data.decode()))
        client_socket.send(data)

def tcp_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(("127.0.0.1", 8888))

    while True:
        message = input("Enter a message: ")
        client_socket.send(message.encode())
        data = client_socket.recv(1024)
        print("Received from server: {}".format(data.decode()))

def main():
    server_thread = threading.Thread(target=tcp_server)
    server_thread.start()

    client_thread = threading.Thread(target=tcp_client)
    client_thread.start()

if __name__ == "__main__":
    main()
